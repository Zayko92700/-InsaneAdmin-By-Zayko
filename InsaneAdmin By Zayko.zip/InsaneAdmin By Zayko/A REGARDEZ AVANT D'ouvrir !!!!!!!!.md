# Insane_admin By Zayko

avec l'aide de  Personne . <3

[Clique ici pour rejoindre le Discord](https://discord.gg/SweatySun)

[Vidéo présentation] [Soon]
